import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ParentComponent } from './parent';

@NgModule({
    declarations: [
        ParentComponent
    ],
    exports: [
        ParentComponent 
    ],
    imports: [
        BrowserModule
    ],
    bootstrap: [
        ParentComponent
    ]

})


export class ParentModule{

    
}