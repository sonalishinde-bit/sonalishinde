import { Component } from '@angular/core';

@Component({
    selector: 'parent',
    templateUrl: 'parentHtml.html'

})
export class ParentComponent{

     data:String;
    tmp;
        GetValue(event){
            this.tmp=event;
        }
        SetInputValue(){
            this.data=this.tmp.target.value;
        }



}