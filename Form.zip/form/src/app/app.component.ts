import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  data:string="";
  onMouseMove(event: MouseEvent) {
    this.data = "Shrikant";
   }
 
     public text: String = 'Text Not submitted yet.';
   public xboolean=true;
 
 
   
 
   mouseMove() {
     this.xboolean = false;
     
   }
 
  
  title = 'formdemo';
}
